import WS, { WebSocket } from 'ws';
import express from 'express';
import http from 'http';
import { Session } from '../common/session.js';
import { getPort } from '../common/environment-variables.js';
import { SecretService } from '../services/secret-service.js';
import { WebSocketServer } from 'ws';

export class Server {
    constructor() {
        this.app = undefined;
        this.httpServer = undefined;
        this.wsServer = undefined;
        this.sessionMap = new Map();
        this.secretService = new SecretService();
        this.timeoutDuration = process.env.timeoutDuration; // milliseconds
    }


start(externalServer) {
    if (!externalServer) {
        this.app = express();
        this.httpServer = http.createServer(this.app);
        // Removed listen() call here
        console.log(`Created internal HTTP server, but NOT listening`);
    } else {
        this.httpServer = externalServer;
        console.log(`Using external HTTP server on port ${getPort()}`);
    }

    this.wsServer = new WebSocketServer({ server: this.httpServer });

        this.wsServer.on('connection', (ws, request) => {
            ws.on('close', () => {
                const session = this.sessionMap.get(ws);
                console.log('WebSocket connection closed.');
                this.deleteConnection(ws);
            });

            ws.on('error', (error) => {
                console.log(`WebSocket Error: ${error}`);
                ws.close();
            });

            ws.on('message', (data, isBinary) => {
                if (ws.readyState !== WS.OPEN) {
                    return;
                }

                const session = this.sessionMap.get(ws);

                if (!session) {
                    const dummySession = new Session(ws, request.headers['audiohook-session-id'], request.url);
                    console.log('Session does not exist.');
                    dummySession.sendDisconnect('error', 'Session does not exist.', {});
                    return;
                }

                if (isBinary) {
                    // console.log("inside binary");
                    session.handleBinaryMessage(data);
                } else {
                    session.processTextMessage(data.toString());
                }
            });

            this.createConnection(ws, request);

            // Optionally enable timeout
            // this.setConnectionTimeout(ws);
        });
    }

    createConnection(ws, request) {
        let session = this.sessionMap.get(ws);

        if (session) {
            return;
        }

        session = new Session(ws, request.headers['audiohook-session-id'], request.url);
        console.log('Creating a new session.');
        this.sessionMap.set(ws, session);
    }

    deleteConnection(ws) {
        const session = this.sessionMap.get(ws);

        if (!session) {
            return;
        }

        try {
            session.close();
        } catch { }

        console.log('Deleting session.');
        this.sessionMap.delete(ws);
    }

    /* Uncomment if you want to use connection timeout
    setConnectionTimeout(ws) {
      ws._timeout = setTimeout(() => {
        if (ws.readyState === WS.OPEN) {
          console.log('Connection timed out.');
          ws.close();
        }
      }, this.timeoutDuration);
    }
    */
}
